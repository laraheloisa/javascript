const btnCriar = document.getElementById("btn-Criar")
const inputTarefa = document.getElementById("input")
const divAviso = document.getElementById("aviso")
const criarDiv = document.getElementById("cria-tarefa")

btnCriar.addEventListener("click", function(){
    let aviso = "Digite algo para criar uma tarefa";
    divAviso.textContent = aviso;
    
})

input.addEventListener('click', function(){    
    divAviso.textContent = " "
    
})
